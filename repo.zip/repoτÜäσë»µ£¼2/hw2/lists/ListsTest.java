package lists;

import org.junit.Test;
import static org.junit.Assert.*;

/** Tests for Lists
 *
 *  @author annetta
 */

public class ListsTest {

    @Test
    public void basicRunsTest() {
        IntList input = IntList.list(1, 2, 3, 1, 2);
        IntList run1 = IntList.list(1, 2, 3);
        IntList run2 = IntList.list(1, 2);
        IntListList result = IntListList.list(run1, run2);
        assertEquals(Lists.naturalRuns(input), result);
    }

    @Test
    public void destructiveTest() {
        IntList input = IntList.list(1, 2, 3, 1, 2);

        IntList run1 = IntList.list(1, 2, 3);
        IntList run2 = IntList.list(1, 2);
        IntListList result = IntListList.list(run1, run2);

        IntListList out = Lists.naturalRuns(input);
        assertEquals(out, result);
    }
    @Test
    public void emptyTest() {
        IntList input = IntList.list();
        IntListList result = IntListList.list();

        IntListList out = Lists.naturalRuns(input);
        assertEquals(Lists.naturalRuns(input), result);
        assertEquals(out, result);
    }

    public static void main(String[] args) {
        System.exit(ucb.junit.textui.runClasses(ListsTest.class));
    }
}
