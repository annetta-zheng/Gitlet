/**
 * TableFilter to filter for entries equal to a given string.
 *
 * @author Matthew Owen
 */
public class EqualityFilter extends TableFilter {

    public EqualityFilter(Table input, String colName, String match) {
        super(input);
        // FIXME: Add your code here.
        _colName1 = input.colNameToIndex(colName);
        x = match;

    }

    @Override
    protected boolean keep() {
        // FIXME: Replace this line with your code.
        return candidateNext().getValue(_colName1).equals(x);
    }
    int _colName1;
    String x;
    // FIXME: Add instance variables?
}
