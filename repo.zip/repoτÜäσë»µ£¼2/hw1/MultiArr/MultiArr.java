/** Multidimensional array
 *  @author Zoe Plaxco
 */

public class MultiArr {
//    public static void main(String[] args) {
//        int[] seq = new int[] {7, 15, 51, 181, 519};
//        int[][] res = diffTriangle(seq);
//        for (int[] i : res) {
//            for (int j : i) {
//                System.out.print(j +" ");
//            }
//            System.out.println();
//        }
//        System.out.println(guess(seq, 5));
//    }
//    public static int[][] diffTriangle(int[] seq) {
//        int[][] result = new int[seq.length][];
//        result[0] = seq;
//        for (int i = 1; i < result.length; i += 1) {
//            result[i] = new int[result[i - 1].length - 1];
//            for (int j = 0; j < result[i].length; j += 1) {
//                result[i][j] = result[i-1][j+1] - result[i-1][j];
//            }
//        }
//        return result;
//    }
//    public static int guess(int[] seq, int n) {
//        int[][] tri = diffTriangle(seq);
//        int binom, result;
//        binom = 1;
//        result = tri[0][0];
//        for (int i = 1; i < tri.length; i += 1) {
//            binom = binom * (n - i + 1) / i;
//            result += binom * tri[i][0];
//        }
//        return result;
//    }
////    public static void main(String[] args) {
////        int[][] a = {{1,3,4}, {},{5},{7,9}};
////        int[][] b = {{1,3,4},{1},{5,6,7,8},{7,9}};
////        printRowAndCol(a);
////        printRowAndCol(b);
////    }
    /**
    {{"hello","you","world"} ,{"how","are","you"}} prints:
    Rows: 2
    Columns: 3

    {{1,3,4},{1},{5,6,7,8},{7,9}} prints:
    Rows: 4
    Columns: 4
    */
    public static void printRowAndCol(int[][] arr) {
        System.out.println("Rows: " + arr.length);
        int m = arr[0].length;
        for (int i =0; i < arr.length; i++) {
            if (arr[i].length > m) {
                m = arr[i].length;
            }
        }
        System.out.println("Columns: " + m);
    }

    /**
    @param arr: 2d array
    @return maximal value present anywhere in the 2d array
    */
    public static int maxValue(int[][] arr) {
        int m = arr[0][0];
        for (int i =0; i < arr.length; i++) {
            for (int j =0; j < arr[i].length; j++) {
                if (arr[i][j] > m) {
                    m = arr[i][j];
                }
            }
        }
        return m;
    }

    /**Return an array where each element is the sum of the
    corresponding row of the 2d array*/
    public static int[] allRowSums(int[][] arr) {
        int[] a = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                a[i] += arr[i][j];
            }
        }
        return a;
    }
}
