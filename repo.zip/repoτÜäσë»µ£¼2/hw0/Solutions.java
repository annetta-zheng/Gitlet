import java.util.Arrays;

import static java.lang.Math.abs;

/** Solutions to the HW0 Java101 exercises.
 *  @author Allyson Park and junwen zheng
 */
public class Solutions {

    /** Returns whether or not the input x is even.
     */
    public static boolean isEven(int x) {
        return x % 2 == 0;
    }

    // TODO: Fill in the method signatures for the other exercises
    // Your methods should be static for this HW. DO NOT worry about what this means.
    // Note that "static" is not necessarily a default, it just happens to be what
    // we want for THIS homework. In the future, do not assume all methods should be
    // static.
    public static int max(int[] a) {
        int max = a[0];
        for (int m : a) {
            if (m > max) {
                max = m;
            }
        }
        return max;
    }

    public static boolean wordBank(String word, String[] bank) {
        for (String w : bank) {
            if (w.equals(word)) {
                return true;
            }
        }
        return false;
    }
    public static boolean wordBankwhile(String word, String[] bank) {
        int i = 0;
        while (i < bank.length) {
            String w = bank[i];
            if (w.equals(word)) {
                return true;
            }
            i++;
        }
        return false;
    }

    public static boolean threeSum(int[] a) {
        Arrays.sort(a);
        if (a[0] == 0) {
            return true;
        } else if (a[0] > 0) {
            return false;
        } else {
            for (int s = 0; s < a.length - 1; s++) {
                int first = a[s];
                int start = s + 1;
                int end = a.length - 1;
                while (start <= end) {
                    int second = a[start];
                    int third = a[end];
                    if (first + second + third == 0
                            || abs(first * 2) == second
                            || abs(first * 2) == third
                            || abs(first) == second + second
                            || abs(first) == third + third) {
                        return true;
//                    } else if (first + second + second > 0) {
//                        return false;
                    } else if (first + second + third > 0) {
                        end--;
                    } else {
                        start++;
                    }
                }
            }
            return false;
        }
    }

}
