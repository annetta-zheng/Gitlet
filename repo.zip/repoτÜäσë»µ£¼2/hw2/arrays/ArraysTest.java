package arrays;

import org.junit.Test;
import static org.junit.Assert.*;

/** Test for Arrays
 *  @author annetta
 */

public class ArraysTest {
    /** Test for c1 catenate
     */
    @Test
    public void catenateTest() {
        int[] A1 = {};
        int[] B1 = {};
        int[] R1 = {};
        assertArrayEquals(Arrays.catenate(A1, B1), R1);

        int[] A2 = {1};
        int[] B2 = {1};
        int[] R2 = {1, 1};
        assertArrayEquals(Arrays.catenate(A2, B2), R2);

        int[] A3 = {};
        int[] B3 = {1, 2, 3, 4, 999, -1};
        int[] C3 = {-1, 2, 3, 4, 999, -1};
        int[] r1 = Arrays.catenate(A3, B3);
        int[] r2 = Arrays.catenate(C3, B3);
        int[] R3 = Arrays.catenate(r1, r2);
        assertArrayEquals(new int[] {1, 2, 3, 4, 999, -1, -1, 2, 3, 4, 999, -1, 1, 2, 3, 4, 999, -1}, R3);

    }

    /** Test for c2 remove
     */
    @Test
    public void removeTest() {
        int[] A1 = {};
        assertArrayEquals(Arrays.remove(A1, 1, 2), null);

        int[] A2 = {1};
        assertArrayEquals(Arrays.remove(A2, 0, 1), A1);

        int[] B3 = {1, 2, 3, 4, 999, -1};
        assertArrayEquals(Arrays.remove(B3, 0, 6), A1);
        assertArrayEquals(Arrays.remove(B3, 1, 0), B3);
        assertArrayEquals(Arrays.remove(B3, 1, 5), new int[] {1});
        assertArrayEquals(Arrays.remove(B3, 5, 1), new int[] {1, 2, 3, 4, 999});

    }

    public static void main(String[] args) {
        System.exit(ucb.junit.textui.runClasses(ArraysTest.class));
    }
}
