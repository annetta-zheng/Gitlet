package image;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

/** test for MatrixUtils
 *  @author annetta
 */

public class MatrixUtilsTest {
    /** test for accumulateVertical
     */
    @Test
    public void accumulate(){
        double[][] m = new double[][] {{10, 4, 5}, {3, 10, 18}, {8, 5, 19}};
        assertEquals(MatrixUtils.accumulate(m, MatrixUtils.Orientation.VERTICAL),
                MatrixUtils.accumulateVertical(m));
    }
    @Test
    public void findVerticalSeamTest(){
        double[][] m = new double[][] {{10, 4, 5}, {3, 10, 18}, {8, 5, 19}};
        System.out.println(Arrays.toString(MatrixUtils.findVerticalSeam(m)));
//        assertEquals(MatrixUtils.accumulate(m, MatrixUtils.Orientation.VERTICAL),
//                MatrixUtils.accumulateVertical(m));
    }
    public static void main(String[] args) {
        System.exit(ucb.junit.textui.runClasses(MatrixUtilsTest.class));
    }
}
