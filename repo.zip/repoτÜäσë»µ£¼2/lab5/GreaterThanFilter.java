/**
 * TableFilter to filter for entries greater than a given string.
 *
 * @author Matthew Owen
 */
public class GreaterThanFilter extends TableFilter {

    public GreaterThanFilter(Table input, String colName, String ref) {
        super(input);
        _colName1 = input.colNameToIndex(colName);
        // FIXME: Add your code here.
        x = ref;
    }

    @Override
    protected boolean keep() {
        // FIXME: Replace this line with your code.
        return candidateNext().getValue(_colName1).compareTo(x) > 0;
    }
    int _colName1;
    String x;
    // FIXME: Add instance variables?
}
