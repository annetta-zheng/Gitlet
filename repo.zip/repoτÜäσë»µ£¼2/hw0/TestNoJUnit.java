/** Tests for hw0.
 *  @author junwen zheng
 */
public class Tester {

    /* Feel free to add your own tests.  For now, you can just follow
     * the pattern you see here.  We'll look into the details of JUnit
     * testing later.
     *
     * To actually run the tests, just use
     *      java Tester
     * (after first compiling your files).
     *
     * DON'T put your HW0 solutions here!  Put them in a separate
     * class and figure out how to call them from here.  You'll have
     * to modify the calls to max, threeSum, and threeSumDistinct to
     * get them to work, but it's all good practice! */

    public static void isEvenTest() {
        System.out.println("isEven(2) should be true, result: " + Solutions.isEven(2));
        System.out.println("isEven(10) should be true, result: " + Solutions.isEven(10));
        System.out.println("isEven(1) should be false, result: " + Solutions.isEven(1));
        System.out.println("isEven(99) should be false, result: " + Solutions.isEven(1));
    }

    public static void maxTest() {
        System.out.println("max {1, 2, 3, 4, 5} should return 5, result: "
                + Solutions.max(new int[] { 1, 2, 3, 4, 5 }));
        System.out.println("max {0, -5, 2, 14, 10} should return 14, result: "
                + Solutions.max(new int[] { 0, -5, 2, 14, 10 }));
        System.out.println("max {1} should return 1, result: "
                + Solutions.max(new int[] { 1 }));
        System.out.println("max { -99, 20000010, 0, 1 } should return 20000010, result: "
                + Solutions.max(new int[] { -99, 20000010, 0, 1 }));
    }

     public static void wordBankTest() {
         String[] adjectives = new String[]{"big", "cool", "fast"};
         System.out.println("wordBank(\"dog\", adjectives) should return False, result: "
                 + Solutions.wordBank("dog", adjectives));
         System.out.println("wordBank(\"big\", adjectives) should return True, result: "
                 + Solutions.wordBankwhile("big", adjectives));
         System.out.println("wordBank(\"big\", adjectives) should return True, result: "
                 + Solutions.wordBank("big", adjectives));

     }


     public static void threeSumTest() {
         System.out.println("threeSum(new int[] { 1, 2, -3 }) should return True, result: "
                 + Solutions.threeSum(new int[] { 1, 2, -3 })); // 1 + 2 - 3 = 0
         System.out.println("threeSum(new int[] { -6, 3, 10, 200 }) should return True, result: "
                 + Solutions.threeSum(new int[] { -6, 3, 10, 200 })); // 3 + 3 - 6 = 0
         System.out.println("threeSum(new int[] {1, -900, 7}) should return False, result: "
                 + Solutions.threeSum(new int[] {1, -900, 7}));
         System.out.println("threeSum(new int[] {0, 1192030,1092030111 }) should return True, result: "
                 + Solutions.threeSum(new int[] {0, 1192030,1092030111 }));
     }

    public static void main(String[] unused) {
        isEvenTest();
        System.out.println("");
        maxTest();
        wordBankTest();
        threeSumTest();
    }

}
