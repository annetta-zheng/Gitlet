/**
 * TableFilter to filter for containing substrings.
 *
 * @author Matthew Owen
 */
public class SubstringFilter extends TableFilter {

    public SubstringFilter(Table input, String colName, String subStr) {
        super(input);
        // FIXME: Add your code here.
        _colName1 = input.colNameToIndex(colName);
        x = subStr;
    }

    @Override
    protected boolean keep() {
        // FIXME: Replace this line with your code.
        return candidateNext().getValue(_colName1).contains(x);
    }
    int _colName1;
    String x;
    // FIXME: Add instance variables?
}
