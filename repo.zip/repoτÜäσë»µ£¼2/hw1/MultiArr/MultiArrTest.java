import static org.junit.Assert.*;
import org.junit.Test;

public class MultiArrTest {

    @Test
    public void testMaxValue() {
        int[][] arr1 = {{1,3,4},{1},{5,6,7,8},{7,9}};
        assertEquals(MultiArr.maxValue(arr1), 9);
        int[][] arr2 = {{-1},{},{},{0}};
        assertEquals(MultiArr.maxValue(arr2), 0);
    }

    @Test
    public void testAllRowSums() {
        int[][] arr1 = {{1,3,4},{1},{5,6,7,8},{7,9}};
        int[] a1 = {8,1,26,16};
        assertArrayEquals(MultiArr.allRowSums(arr1), a1);
        int[][] arr2 = {{-1},{1},{3,2},{0}};
        assertArrayEquals(MultiArr.allRowSums(arr2), new int[] {-1,1,5,0});
    }


    /* Run the unit tests in this file. */
    public static void main(String... args) {
        System.exit(ucb.junit.textui.runClasses(MultiArrTest.class));
    }
}
